# RQ1 frozen source optimization: slim analysis bundle

Derived only from the immutable 30-cell archive (SHA-256: 6980c68109639305d08f7cbaa4669ed3ccbeb5f3fed1908914a1efc0ec95ad06).
The server original and source archive are not modified. SecReq CSV SHA-256: d6d1535bacb754f3390a60638f9de38bacd72499f694f34b14808b01b5c77083.

- cells.jsonl: 30 cell-level records, source split IDs, provenance, selected iteration and source-test metrics.
- candidates.jsonl: all 630 p0/candidate Prompt texts and validation metrics, preserving duplicate texts and original iteration order.
- iteration_events.jsonl: 600 proposer/feedback lineage events, hashes, backtracking and usage.
- validation_predictions.jsonl: 96,390 per-candidate validation-item gold/prediction and three vote labels.
- source_test_predictions.jsonl: 12,240 per-item p0/p* source-test gold/prediction and three vote labels.
- SecReq_510_BTAPE.csv: original 510-row source text/label catalog; item IDs are zero-based row indices.
- matrix-manifest.json and matrix-summary.json: copied from the immutable archive.

Omitted to reduce size: full raw model completions, rendered classifier/proposer requests, token IDs/logprobs, HTTP metadata and repeated pool-evaluation prediction traces. This bundle supports candidate trajectory, source validation ranking, p0/p* source-test and GitReq deployment analysis, but it is not a replacement for forensic replay from the full archive.
